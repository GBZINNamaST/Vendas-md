const { EmbedBuilder, ApplicationCommandType, ApplicationCommandOptionType, ActionRowBuilder, ButtonBuilder, ComponentType, PermissionFlagsBits } = require("discord.js");
const { JsonDatabase } = require("wio.db");
const General = new JsonDatabase({ databasePath: "./DataBaseJson/General.json" });
const config = new JsonDatabase({ databasePath: "./DataBaseJson/configbasicasindex.json" });
const cooldowns = new Map();
const fs = require("fs"); // Changed to require("fs")
const fsPromises = require("fs/promises"); // Added for async file operations
const path = require("path");

module.exports = {
  name: "gerar",
  description: "[ Gerador ] Gere algum serviço do bot",
  type: ApplicationCommandType.ChatInput,
  default_member_permissions: PermissionFlagsBits.Administrator, 
    options: [
    {
      name: "serviço",
      description: "qual serviço você deseja gerar?",
      type: ApplicationCommandOptionType.String,
      required: true
    }
  ],

  run: async (client, interaction) => {

    const stockDirectory = path.join(__dirname, "../../Stock");
    const files = fs.readdirSync(stockDirectory); // Using fs for synchronous read

    const service = interaction.options.getString("serviço");
    const canalCorreto = General.get(`${interaction.guild.id}.canal_gerador`);
    const cargoCorreto = General.get(`${interaction.guild.id}.cargo_gerador`);
    const isSystemOn = General.get(`${interaction.guild.id}.sistema`);
    const cooldownTime = General.get(`${interaction.guild.id}.gen_cooldawn`) || 10000;
    const now = Date.now();

    if (cooldowns.has(interaction.user.id)) {
      const expirationTime = cooldowns.get(interaction.user.id);
      const timeLeft = expirationTime - now;

      if (timeLeft > 0) {
        const endTimestamp = Math.floor((now + timeLeft) / 1000);
        return interaction.reply({
          content: `❌ | Você está em cooldown! Irá terminar em: <t:${endTimestamp}:f> (<t:${endTimestamp}:R>)`,
          ephemeral: true
        });
      }
    }

    cooldowns.set(interaction.user.id, now + cooldownTime);

    if (isSystemOn === "off") {
      return interaction.reply({ content: `❌ | O sistema do gerador está offline para este servidor no momento.`, ephemeral: true });
    }

    if (!files.includes(`${service}.txt`)) {
      return interaction.reply({ content: `❌ | O serviço \`${service}\` não existe em meu stock!`, ephemeral: true });
    }

    if (!canalCorreto) {
      return interaction.reply({ content: `❌ | Canal de geração não configurado.`, ephemeral: true });
    }

    if (interaction.channel.id !== canalCorreto) {
      return interaction.reply({ content: `❌ | Se redirecione até o canal <#${canalCorreto}> e use o comando lá!`, ephemeral: true });
    }

    if (cargoCorreto) {
      const member = interaction.member;
      if (!member.roles.cache.has(cargoCorreto)) {
        return interaction.reply({ content: `❌ | Você não tem o cargo <@&${cargoCorreto}> para usar este comando!`, ephemeral: true });
      }
    }

    const servicePath = path.join(stockDirectory, `${service}.txt`);
    let lines;

    try {
      lines = fs.readFileSync(servicePath, "utf-8").trim().split("\n");
    } catch (err) {
      console.error(`Erro ao ler o arquivo ${servicePath}: ${err.message}`);
      return interaction.reply({ content: `❌ | Ocorreu um erro ao ler o serviço.`, ephemeral: true });
    }

    lines = lines.filter(line => line.trim() !== "");

    if (lines.length === 0) {
      return interaction.reply({ content: `❌ | O serviço \`${service}\` está vazio!`, ephemeral: true });
    }

    const lastLine = lines.pop();

    try {
      fs.writeFileSync(servicePath, lines.join("\n"), "utf-8");
    } catch (err) {
      console.error(`Erro ao salvar o arquivo ${servicePath}: ${err.message}`);
      return interaction.reply({ content: `❌ | Ocorreu um erro ao salvar o serviço.`, ephemeral: true });
    }

    const dataObject = new Date();
    const unixTimestamp = Math.floor(dataObject.getTime() / 1000);
    const formattedDate = `<t:${unixTimestamp}:f> (<t:${unixTimestamp}:R>)`;

    const embedGerado = new EmbedBuilder()
      .setTitle(`${General.get(`${interaction.guild.id}.titulo_gen`) || `${interaction.guild.name}`} | Conta gerada com êxito`)
      .setDescription(`Pronto ${interaction.user}, o serviço \`${service}\` que você selecionou, já foi gerado e já está em seu privado, caso a conta não funcione não reclame, algumas delas são uncheckeds ou antigas.`)
      .setColor(`${General.get(`${interaction.guild.id}.cor_gen`) || `#2e2e2e`}`)
      .setFooter({ text: `${interaction.user.username}`, iconURL: interaction.user.displayAvatarURL() })
      .setTimestamp();

    const serverBanner1 = General.get(`${interaction.guild.id}.banner_gen`);
    const botBanner1 = config.get(`banner_bot`);
    const imageUrl1 = serverBanner1 || botBanner1;

    if (imageUrl1) {
      embedGerado.setImage(imageUrl1);
    }

    await interaction.reply({ embeds: [embedGerado] });

    const embedUserDM = new EmbedBuilder()
      .setTitle(`${General.get(`${interaction.guild.id}.titulo_gen`) || `${interaction.guild.name}`} | Conta gerada com êxito`)
      .setDescription(`\`\`\`${lastLine}\`\`\`\n**${Emojis.get(`_transfer_emoji`)} | Serviço selecionado:** ${service}\n**${Emojis.get(`date_emoji`)} | Data:** ${formattedDate}\n**${Emojis.get(`usuario2`)} | Autor:** ${interaction.user}`)
      .setThumbnail(config.get(`thumbnail_bot`) || interaction.guild.iconURL())
      .setColor(`${General.get(`${interaction.guild.id}.cor_gen`) || `#2e2e2e`}`)
      .setFooter({ text: `Clique no botão "Copiar Conta" para ficar mais fácil de copiar.` });

    const serverBanner = General.get(`${interaction.guild.id}.banner_gen`);
    const botBanner = config.get(`banner_bot`);
    const imageUrl = serverBanner || botBanner;

    if (imageUrl) {
      embedUserDM.setImage(imageUrl);
    }

    const botaoDmUser = new ActionRowBuilder()
      .addComponents(
        new ButtonBuilder()
          .setCustomId("copiarconta")
          .setLabel(`Copiar Conta`)
          .setEmoji("1381349625994154024")
          .setStyle(1),
        
      );

    try {
      await interaction.user.send({ embeds: [embedUserDM], components: [botaoDmUser] });
    } catch (err) {
      console.error(`Erro ao enviar DM para ${interaction.user.tag}: ${err.message}`);
      return interaction.reply({ content: `❌ | Ocorreu um erro ao enviar a DM com o serviço removido.`, ephemeral: true });
    }

    const filter = i => i.customId === "copiarconta" || i.customId === "addbot";
    const collector = interaction.user.dmChannel.createMessageComponentCollector({ filter, time: 60000 });

    collector.on("collect", async i => {
      if (i.customId === "copiarconta") {
        await i.update({
          components: [
            new ActionRowBuilder().addComponents(
              new ButtonBuilder()
                .setCustomId("copiarconta")
                .setLabel(`Copiar Conta`)
                .setEmoji("1381349625994154024")
                .setStyle(1)
            )
          ]
        });

        await i.followUp({ content: `${lastLine}`, ephemeral: false });
      }

      if (i.customId === "addbot") {
        await i.reply({ content: `discord.gg/dreamapps`, ephemeral: true });
      }
    });
  }
};
