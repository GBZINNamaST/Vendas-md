const { EmbedBuilder, ApplicationCommandType, ActionRowBuilder, ButtonBuilder } = require("discord.js");

async function Gerenciar(interaction, client) {


    const row1 = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId("configcargos")
                .setLabel('Cargos')
                .setEmoji(`1309962502834229268`)
                .setStyle(2),
            new ButtonBuilder()
                .setCustomId("personalizarcanais")
                .setLabel('Canais')
                .setEmoji(`1309962501877923931`)
                .setStyle(2),
        )

    const row2 = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId("formasdepagamentos")
                .setLabel('Formas de pagamento')
                .setEmoji(`1309962449696456764`)
                .setStyle(1),
        )

    const row3 = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId("voltar00")
            .setEmoji(`1305590970062082078`)
            .setStyle(2),
        new ButtonBuilder()
            .setCustomId(`voltar1`)
            .setEmoji('1292237216915128361')
            .setDisabled(true)
            .setStyle(1)
    )


    if (interaction.message == undefined) {
        interaction.reply({ embeds: [], components: [row1, row2, row3], content: `O que precisa configurar?` })
    } else {
        await interaction.update({ embeds: [], components: [row1, row2, row3], content: `O que precisa configurar?` })
    }

}



module.exports = {
    Gerenciar
}
