const { ButtonBuilder, ButtonStyle, ActionRowBuilder, PermissionsBitField, EmbedBuilder, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const fetch = require('node-fetch');

// Função para criar o painel de ajuda
async function createHelpPanel(interaction) {
    try {
        await interaction.deferUpdate(); // Garante mais tempo pra processar
        const notifyDevsButton = new ButtonBuilder()
            .setCustomId('notifyDevs')
            .setLabel('Notificar Developers')
            .setEmoji("1306695413100838983")
            .setStyle(ButtonStyle.Secondary);

        const row = new ActionRowBuilder().addComponents(notifyDevsButton);

        const embed = new EmbedBuilder()
            .setColor('#2F3136')
            .setAuthor({
                name: 'Painel de Ajuda - Suflay',
                iconURL: 'https://cdn.discordapp.com/attachments/1378358712992927744/1378542873087311984/image.png?ex=683da459&is=683c52d9&hm=05aad7393993a2ee0514e839aa76e24fab01a0d156d13be8e68b4f97142da5ae&'
            })
            .setThumbnail("https://cdn.discordapp.com/emojis/1350325127371558975.webp?size=96&animated=true")
            .setImage("https://cdn.discordapp.com/attachments/1378796348404400269/1378812735533613176/image_5.png?ex=683df6ed&is=683ca56d&hm=57c2b037ab3a0f479e5e5c976aadfc8c5266eb5dfb83e5f489c21bb1dc0a486b&")
            .setDescription('> Envie uma notificação aos desenvolvedores:\n-# `📡` Use o botão abaixo.');

        await interaction.editReply({
            embeds: [embed],
            components: [row],
            ephemeral: true
        });
    } catch (err) {
        console.error('Erro ao atualizar painel de ajuda:', err);
    }
}

// Função para lidar com interações de botão
async function handleButtonInteraction(interaction, client) {
    try {
        if (interaction.customId === 'ajudasuflay') {
            await createHelpPanel(interaction);
        } else if (interaction.customId === 'notifyDevs') {
            if (!interaction.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
                await interaction.update({
                    content: '-# Você precisa de permissão de administrador para notificar os desenvolvedores!',
                    embeds: [],
                    components: [],
                    ephemeral: true
                });
                return;
            }

            const modal = new ModalBuilder()
                .setCustomId('notifyDevsModal')
                .setTitle('Notificar Desenvolvedores');

            const messageInput = new TextInputBuilder()
                .setCustomId('devMessageInput')
                .setLabel('Digite sua mensagem')
                .setStyle(TextInputStyle.Paragraph)
                .setRequired(true);

            const row = new ActionRowBuilder().addComponents(messageInput);
            modal.addComponents(row);

            await interaction.showModal(modal);
            console.log('Modal exibido para:', interaction.user.tag);
        }
    } catch (error) {
        console.error('Erro ao processar interação de botão:', error);
        if (!interaction.deferred && !interaction.replied) {
            await interaction.reply({
                content: '-# Ocorreu um erro ao processar a interação. Verifique os logs.',
                ephemeral: true
            }).catch(err => console.error('Erro ao responder:', err));
        }
    }
}

// Função para lidar com submissões de modal
async function handleModalSubmit(interaction, client) {
    try {
        if (interaction.customId === 'notifyDevsModal') {
            await interaction.deferReply({ ephemeral: true }); // Evita timeout
            const message = interaction.fields.getTextInputValue('devMessageInput');
            if (!message) {
                await interaction.editReply({
                    content: '-# Nenhuma mensagem fornecida. Tente novamente.',
                    ephemeral: true
                });
                return;
            }

            const webhookUrl = 'https://discord.com/api/webhooks/1379965759190466631/8afFo4Prdyl5F0JmColyaBy9tqZgjnF9En4z83_o5BgCE5y4IyPa3RJzL1d6jVjFp2D2';
            const embed = new EmbedBuilder()
                .setColor('#FF0000')
                .setAuthor({
                    name: 'Notificação de Usuário',
                    iconURL: interaction.user.displayAvatarURL()
                })
                .setDescription(`> \`\📡\` Mensagem enviada por **${interaction.user.tag}** no servidor **${interaction.guild.name}**:\n\n${message}`)
                .addFields(
                    { name: '`🆔` Usuário ID', value: interaction.user.id },
                    { name: '`📅` Data/Hora', value: new Date().toLocaleString('pt-BR', { timeZone: 'America/Sao_Paulo' }) }
                )
                .setFooter({
                    text: `Sistema de Notificação | DreamPro!`,
                    iconURL: 'https://images-ext-1.discordapp.net/external/t-fI531Uo_MKfOHkwM76QXOy-_F6KSaot4X1-Nzv6BE/https/cdn.discordapp.com/avatars/1362091002239782912/f451048f2149bf4d9c0a78b7cff37442.webp'
                })
                .setTimestamp();

            await fetch(webhookUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ embeds: [embed.toJSON()] })
            });

            await interaction.editReply({
                content: '-# Mensagem enviada aos desenvolvedores com sucesso!',
                ephemeral: true
            });
            console.log('Mensagem enviada ao webhook por:', interaction.user.tag);
        }
    } catch (error) {
        console.error('Erro ao processar submissão do modal:', error);
        await interaction.editReply({
            content: '-# Ocorreu um erro ao enviar a mensagem. Verifique os logs.',
            ephemeral: true
        }).catch(err => console.error('Erro ao responder:', err));
    }
}

module.exports = {
    createHelpPanel,
    handleButtonInteraction,
    handleModalSubmit
};